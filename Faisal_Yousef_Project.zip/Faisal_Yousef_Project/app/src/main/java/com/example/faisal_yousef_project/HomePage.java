package com.example.faisal_yousef_project;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.gson.JsonObject;

import org.json.JSONObject;

public class HomePage extends AppCompatActivity {

    RequestQueue rq;
    SharedPreferences sp;
    ImageView weatherImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        rq= Volley.newRequestQueue(this);
        Button btn_goto_firebase=findViewById(R.id.btn_goto_firebase);
        Button btn_goto_weather=findViewById(R.id.btn_goto_weather);
        Button btn_goto_sqlite=findViewById(R.id.btn_goto_sqlite);


        sp= PreferenceManager.getDefaultSharedPreferences(this);

        btn_goto_firebase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePage.this,FireBase.class));
            }
        });
        btn_goto_weather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePage.this,OpenWeather.class) );
            }
        });
        btn_goto_sqlite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePage.this,FireBase.class) );
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        rq.add(Helper.weather(this));
    }




}